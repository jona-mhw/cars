# Para Mi Yo del Futuro 🚗🧠

**Fecha**: 24 de Diciembre, 2024  
**Proyecto**: Neuro Drive - Simulación de IA Aprendiendo a Conducir  
**Usuario**: Un desarrollador entusiasta que quería ver IA aprender en tiempo real

---

## 🎯 El Objetivo Original

El usuario quería crear una app web que mostrara **aprendizaje automático en acción** - algo visual donde pudieras ver "cómo las figuras aprenden a caminar" pero más simple. Decidimos hacer **coches que aprenden a esquivar obstáculos** usando:

1. **Redes Neuronales** (desde cero, sin librerías)
2. **Algoritmo Genético** (selección natural + mutación)
3. **Visualización en tiempo real** del "cerebro" del líder

---

## 🏗️ Arquitectura del Proyecto

```
learning-excercise/
├── src/
│   ├── main.ts      # Loop principal, generaciones, UI
│   ├── car.ts       # Física del coche, sensores, NN, stagnation
│   ├── sensor.ts    # Ray-casting para detectar obstáculos
│   ├── network.ts   # Red neuronal feed-forward + mutación
│   ├── road.ts      # Carretera y bordes
│   ├── visualizer.ts # Renderizado del cerebro del líder
│   └── style.css    # Tema oscuro premium
├── index.html       # Dashboard con leyenda y controles
└── README.md        # Documentación para el usuario
```

---

## 🧠 Cómo Funciona

### Red Neuronal
- **7 entradas** (sensores de distancia)
- **6 neuronas ocultas**
- **4 salidas** (arriba, izquierda, derecha, abajo)
- Activación binaria (>0.5 = activo)

### Algoritmo Genético
1. 100 coches nacen con cerebros aleatorios (o mutados del mejor anterior)
2. Compiten hasta que **todos chocan**
3. El que llegó **más lejos** pasa su cerebro a la siguiente generación
4. Las copias tienen **mutaciones variables** (algunos pequeñas, otros grandes)

### Visualizador
- Muestra nodos y conexiones
- Colores según peso (amarillo=positivo, azul=negativo)
- Se actualiza en tiempo real

---

## 🐛 Problemas que Resolvimos (en orden)

### 1. Los coches no chocaban con los obstáculos
**Causa**: Sensores y colisiones solo detectaban bordes de carretera.
**Solución**: Agregamos detección de tráfico en `Sensor.update()` y `Car.#assessDamage()`.

### 2. El primer obstáculo estaba justo enfrente
**Causa**: Los coches nacían y chocaban inmediatamente sin tiempo de aprender.
**Solución**: Movimos los primeros obstáculos a los carriles laterales.

### 3. Generaciones se reiniciaban solas
**Causa**: Había un timeout de 8 segundos que forzaba nueva generación.
**Solución**: Ahora solo termina cuando **todos** los coches chocan.

### 4. El coche se "teletransportaba"
**Causa**: Al cambiar el líder, la cámara saltaba instantáneamente.
**Solución**: Agregamos interpolación suave (`lerp`) para la cámara.

### 5. Los coches encontraban un "hueco seguro" y se quedaban ahí
**Causa**: AI y obstáculos se movían a la misma velocidad.
**Solución**: AI ahora es más rápida (velocidad 4 vs 2), obligándolos a esquivar constantemente.

### 6. El coche hacía "vaivén" sin avanzar
**Causa**: Retrocedía y avanzaba, técnicamente "moviéndose" pero sin progreso real.
**Solución**: Implementamos `bestY` - si no supera su **récord personal** en 2.5 segundos, muere.

---

## 📊 Estado Actual

### ✅ Funciona
- Simulación completa con 100 coches
- Red neuronal y mutación
- Visualizador del cerebro
- Sensores ray-casting (7 rayos, alcance 200)
- Colisión con bordes y obstáculos
- Cámara suave
- UI con leyenda explicativa
- Guardado/carga de cerebros en localStorage

### ⚠️ Posible mejora pendiente
El detector de estancamiento usa `bestY` - si el coche no mejora su mejor posición en 150 frames (~2.5s), muere. Esto debería funcionar, pero el usuario reportó que aún hacía vaivén. Puede que necesite:
1. Reducir el límite de frames
2. Aumentar el umbral de mejora (actualmente 5 unidades)
3. O simplemente probar de nuevo después del último fix

---

## 🎨 Colores en la UI

| Color | Significado |
|-------|-------------|
| Azul transparente | Población de IA aprendiendo |
| Azul brillante con glow | Líder actual |
| Naranja | Obstáculos (DUMMY cars) |
| Gris | Coches que chocaron |

---

## 🚀 Para Continuar

1. **Refresca la página** y presiona "Reiniciar Evolución"
2. Observa si el detector de estancamiento funciona
3. Si aún hay vaivén, reduce `STAGNATION_LIMIT` en `car.ts` (línea ~20)
4. Considera agregar más obstáculos o patrones más difíciles
5. Prueba guardar un cerebro bueno para no perder progreso

---

## 💡 Notas para mi Yo Futuro

- El usuario se emociona cuando las cosas funcionan - ¡celebra los logros!
- Habla en español, es chileno
- Prefiere explicaciones claras de qué está pasando
- Le gusta entender el "por qué" detrás de los cambios
- El proyecto usa Vite + TypeScript vanilla (sin frameworks)

**¡Feliz Navidad!** 🎄 Este fue un proyecto genial de Nochebuena.
