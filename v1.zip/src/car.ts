import { Sensor } from "./sensor";
import { Network } from "./network";

export class Car {
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number = 0;
  acceleration: number = 0.2;
  maxSpeed: number;
  friction: number = 0.05;
  angle: number = 0;
  damaged: boolean = false;
  controlType: "AI" | "KEYS" | "DUMMY";

  // Stagnation detection - track best position ever reached
  bestY: number = Infinity; // Best (lowest) Y position reached
  stagnationFrames: number = 0;
  static readonly STAGNATION_LIMIT = 60; // ~1 second at 60fps - kill quickly

  // Track movement direction to detect oscillation (vaivén)
  previousY: number;
  directionChanges: number = 0;
  static readonly MAX_DIRECTION_CHANGES = 8; // Kill if oscillating too much
  lastDirection: number = 0; // -1: backward, 0: no movement, 1: forward

  sensor: Sensor | null = null;
  brain: Network | null = null;
  controls: { forward: boolean; left: boolean; right: boolean; reverse: boolean };
  fitness: number = 0;

  constructor(x: number, y: number, width: number, height: number, controlType: "AI" | "KEYS" | "DUMMY" = "AI", maxSpeed: number = 3) {
    this.x = x;
    this.y = y;
    this.bestY = y; // Initialize best position for stagnation detection
    this.previousY = y;
    this.width = width;
    this.height = height;
    this.maxSpeed = maxSpeed;
    this.controlType = controlType;

    this.controls = { forward: false, left: false, right: false, reverse: false };

    if (controlType === "AI") {
      this.sensor = new Sensor(this);
      this.brain = new Network([this.sensor.rayCount, 6, 4]);
    }

    if (controlType === "KEYS") {
      this.sensor = new Sensor(this);
      this.#addKeyboardListeners();
    }

    if (controlType === "DUMMY") {
      this.controls.forward = true; // Dummy cars just go forward
    }
  }

  update(roadBorders: { x: number; y: number }[][], traffic: Car[] = []) {
    if (!this.damaged) {
      this.#move();

      if (this.sensor) {
        this.sensor.update(roadBorders, traffic);
        const offsets = this.sensor.readings.map((s: any) => s == null ? 0 : 1 - s.offset);

        if (this.brain) {
          const outputs = Network.feedForward(offsets, this.brain);
          this.controls.forward = outputs[0] > 0.5;
          this.controls.left = outputs[1] > 0.5;
          this.controls.right = outputs[2] > 0.5;

          // DISABLE REVERSE for AI to prevent oscillation
          this.controls.reverse = false;
        }
      }

      // Only AI cars check for collision with traffic
      if (this.controlType !== "DUMMY") {
        this.#assessDamage(roadBorders, traffic);

        // Detect oscillation (vaivén) - car changing direction repeatedly
        const yDelta = this.y - this.previousY;
        const currentDirection = yDelta < -0.5 ? -1 : (yDelta > 0.5 ? 1 : 0);

        if (currentDirection !== 0 && currentDirection !== this.lastDirection) {
          // Direction changed significantly
          if (this.lastDirection !== 0) {
            this.directionChanges++;
            if (this.directionChanges > Car.MAX_DIRECTION_CHANGES) {
              this.damaged = true; // Kill oscillating car
              return;
            }
          }
          this.lastDirection = currentDirection;
        }
        this.previousY = this.y;

        // Stagnation check: car must keep improving its best position
        // If current Y is better (lower) than bestY, update bestY and reset timer
        if (this.y < this.bestY - 1) { // Must improve by at least 1 unit
          this.bestY = this.y;
          this.stagnationFrames = 0;
        } else {
          this.stagnationFrames++;
          if (this.stagnationFrames > Car.STAGNATION_LIMIT) {
            this.damaged = true; // "Dies" from not improving
          }
        }
      }

      if (!this.damaged) {
        this.fitness -= this.speed;
      }
    }
  }

  #assessDamage(roadBorders: { x: number; y: number }[][], traffic: Car[]) {
    for (let i = 0; i < roadBorders.length; i++) {
      const border = roadBorders[i];
      if (this.#polysIntersect(this.getPolygon(), border)) {
        this.damaged = true;
        return;
      }
    }
    for (let i = 0; i < traffic.length; i++) {
      if (this.#polysIntersect(this.getPolygon(), traffic[i].getPolygon())) {
        this.damaged = true;
        return;
      }
    }
  }

  getPolygon() {
    const points = [];
    const rad = Math.hypot(this.width, this.height) / 2;
    const alpha = Math.atan2(this.width, this.height);
    points.push({
      x: this.x - Math.sin(this.angle - alpha) * rad,
      y: this.y - Math.cos(this.angle - alpha) * rad
    });
    points.push({
      x: this.x - Math.sin(this.angle + alpha) * rad,
      y: this.y - Math.cos(this.angle + alpha) * rad
    });
    points.push({
      x: this.x - Math.sin(Math.PI + this.angle - alpha) * rad,
      y: this.y - Math.cos(Math.PI + this.angle - alpha) * rad
    });
    points.push({
      x: this.x - Math.sin(Math.PI + this.angle + alpha) * rad,
      y: this.y - Math.cos(Math.PI + this.angle + alpha) * rad
    });
    return points;
  }

  #polysIntersect(poly1: { x: number; y: number }[], poly2: { x: number; y: number }[]) {
    for (let i = 0; i < poly1.length; i++) {
      for (let j = 0; j < poly2.length - 1; j++) {
        const touch = this.#getIntersection(
          poly1[i],
          poly1[(i + 1) % poly1.length],
          poly2[j],
          poly2[j + 1]
        );
        if (touch) return true;
      }
    }
    return false;
  }

  #getIntersection(A: any, B: any, C: any, D: any) {
    const tTop = (D.x - C.x) * (A.y - C.y) - (D.y - C.y) * (A.x - C.x);
    const uTop = (C.y - A.y) * (A.x - B.x) - (C.x - A.x) * (A.y - B.y);
    const bottom = (D.y - C.y) * (B.x - A.x) - (D.x - C.x) * (B.y - A.y);

    if (bottom != 0) {
      const t = tTop / bottom;
      const u = uTop / bottom;
      if (t >= 0 && t <= 1 && u >= 0 && u <= 1) {
        return {
          x: A.x + (B.x - A.x) * t,
          y: A.y + (B.y - A.y) * t,
          offset: t
        };
      }
    }
    return null;
  }

  #move() {
    if (this.controls.forward) this.speed += this.acceleration;
    if (this.controls.reverse) this.speed -= this.acceleration;

    if (this.speed > this.maxSpeed) this.speed = this.maxSpeed;
    if (this.speed < -this.maxSpeed / 2) this.speed = -this.maxSpeed / 2;

    if (this.speed > 0) this.speed -= this.friction;
    if (this.speed < 0) this.speed += this.friction;

    if (Math.abs(this.speed) < this.friction) this.speed = 0;

    if (this.speed != 0) {
      const flip = this.speed > 0 ? 1 : -1;
      if (this.controls.left) this.angle += 0.03 * flip;
      if (this.controls.right) this.angle -= 0.03 * flip;
    }

    this.x -= Math.sin(this.angle) * this.speed;
    this.y -= Math.cos(this.angle) * this.speed;
  }

  draw(ctx: CanvasRenderingContext2D, color: string, drawSensor: boolean = false) {
    if (this.damaged) ctx.fillStyle = "gray";
    else ctx.fillStyle = color;

    ctx.beginPath();
    const polygon = this.getPolygon();
    ctx.moveTo(polygon[0].x, polygon[0].y);
    for (let i = 1; i < polygon.length; i++) {
      ctx.lineTo(polygon[i].x, polygon[i].y);
    }
    ctx.fill();

    if (this.sensor && drawSensor) {
      this.sensor.draw(ctx);
    }
  }

  #addKeyboardListeners() {
    document.onkeydown = (event) => {
      switch (event.key) {
        case "ArrowLeft": this.controls.left = true; break;
        case "ArrowRight": this.controls.right = true; break;
        case "ArrowUp": this.controls.forward = true; break;
        case "ArrowDown": this.controls.reverse = true; break;
      }
    };
    document.onkeyup = (event) => {
      switch (event.key) {
        case "ArrowLeft": this.controls.left = false; break;
        case "ArrowRight": this.controls.right = false; break;
        case "ArrowUp": this.controls.forward = false; break;
        case "ArrowDown": this.controls.reverse = false; break;
      }
    };
  }
}
