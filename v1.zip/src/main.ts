import './style.css';
import { Car } from './car';
import { Road } from './road';
import { Network } from './network';
import { Visualizer } from './visualizer';

const carCanvas = document.getElementById("carCanvas") as HTMLCanvasElement;
const carCtx = carCanvas.getContext("2d")!;
const networkCanvas = document.getElementById("networkCanvas") as HTMLCanvasElement;
const networkCtx = networkCanvas.getContext("2d")!;

const mutationRateSlider = document.getElementById("mutationRate") as HTMLInputElement;
const mutationValLabel = document.getElementById("mutationVal") as HTMLSpanElement;
const genLabel = document.getElementById("generationCount") as HTMLSpanElement;
const aliveLabel = document.getElementById("aliveCount") as HTMLSpanElement;
const fitnessLabel = document.getElementById("bestFitness") as HTMLSpanElement;

function updateCanvasSize() {
  carCanvas.width = 400;
  carCanvas.height = window.innerHeight * 0.9;
  networkCanvas.width = 400;
  networkCanvas.height = 300;
}

window.addEventListener('resize', updateCanvasSize);
updateCanvasSize();

const road = new Road(carCanvas.width / 2, carCanvas.width * 0.9);

// Traffic cars are DUMMY type - they just go forward slowly, no brains
// IMPORTANT: First obstacle NOT in center lane to give AI time to learn!
function createTraffic() {
  return [
    // First obstacles on sides - easy start
    new Car(road.getLaneCenter(0), -200, 30, 50, "DUMMY", 2),
    new Car(road.getLaneCenter(2), -200, 30, 50, "DUMMY", 2),

    // First center obstacle - needs to dodge
    new Car(road.getLaneCenter(1), -400, 30, 50, "DUMMY", 2),

    // Progressive difficulty
    new Car(road.getLaneCenter(0), -600, 30, 50, "DUMMY", 2),
    new Car(road.getLaneCenter(2), -600, 30, 50, "DUMMY", 2),

    new Car(road.getLaneCenter(1), -800, 30, 50, "DUMMY", 2),
    new Car(road.getLaneCenter(0), -800, 30, 50, "DUMMY", 2),

    new Car(road.getLaneCenter(1), -1000, 30, 50, "DUMMY", 2),
    new Car(road.getLaneCenter(2), -1000, 30, 50, "DUMMY", 2),

    // Harder section - two blocking, one open
    new Car(road.getLaneCenter(0), -1200, 30, 50, "DUMMY", 2),
    new Car(road.getLaneCenter(1), -1200, 30, 50, "DUMMY", 2),
  ];
}

let traffic = createTraffic();

const N = 100; // Population size
let generation = 1;
let cars = generateCars(N);
let bestCar = cars[0];

// Smooth camera variables
let cameraY = 100;
const CAMERA_SMOOTHNESS = 0.05; // Lower = smoother camera

if (localStorage.getItem("bestBrain")) {
  for (let i = 0; i < cars.length; i++) {
    cars[i].brain = JSON.parse(localStorage.getItem("bestBrain")!);
    if (i != 0) {
      Network.mutate(cars[i].brain!, 0.2); // Higher mutation when loading
    }
  }
}

function generateCars(N: number) {
  const cars = [];
  for (let i = 1; i <= N; i++) {
    // AI cars are FASTER (maxSpeed=4) than traffic (maxSpeed=2)
    // This forces them to constantly navigate and dodge
    cars.push(new Car(road.getLaneCenter(1), 100, 30, 50, "AI", 4));
  }
  return cars;
}

function save() {
  localStorage.setItem("bestBrain", JSON.stringify(bestCar.brain));
}

function discard() {
  localStorage.removeItem("bestBrain");
  location.reload();
}

document.getElementById("saveBest")?.addEventListener("click", save);
document.getElementById("discardBrain")?.addEventListener("click", discard);

mutationRateSlider.addEventListener("input", (e) => {
  mutationValLabel.innerText = (e.target as HTMLInputElement).value;
});

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

function animate(time: number = 0) {
  for (let i = 0; i < traffic.length; i++) {
    traffic[i].update(road.borders);
  }
  for (let i = 0; i < cars.length; i++) {
    cars[i].update(road.borders, traffic);
  }

  // Find best car - the one that traveled furthest (lowest Y)
  // Consider ALL cars, not just active ones, for proper evolution
  bestCar = cars.reduce((best, car) => {
    // Prefer the car that went furthest before crashing (or is still alive)
    const carDistance = 100 - car.y;
    const bestDistance = 100 - best.y;
    return carDistance > bestDistance ? car : best;
  }, cars[0]);

  // For visualization, prefer an alive car if available
  const activeCars = cars.filter(c => !c.damaged);
  const visualBestCar = activeCars.length > 0
    ? activeCars.reduce((best, car) => car.y < best.y ? car : best, activeCars[0])
    : bestCar;

  // Smooth camera movement (prevents teleportation)
  const targetCameraY = visualBestCar.y;
  cameraY = lerp(cameraY, targetCameraY, CAMERA_SMOOTHNESS);

  carCanvas.height = window.innerHeight * 0.9; // clear
  networkCanvas.height = 300;

  carCtx.save();
  carCtx.translate(0, -cameraY + carCanvas.height * 0.7);

  road.draw(carCtx);

  // Draw traffic (obstacles) - orange/red color
  for (let i = 0; i < traffic.length; i++) {
    traffic[i].draw(carCtx, "#ff6b35");
  }

  // Draw all AI cars (transparent)
  carCtx.globalAlpha = 0.2;
  for (let i = 0; i < cars.length; i++) {
    if (cars[i] !== visualBestCar) {
      cars[i].draw(carCtx, "#00d2ff");
    }
  }
  carCtx.globalAlpha = 1;

  // Draw leader with glow effect
  carCtx.shadowColor = "#00d2ff";
  carCtx.shadowBlur = 15;
  visualBestCar.draw(carCtx, "#00d2ff", true);
  carCtx.shadowBlur = 0;

  carCtx.restore();

  // Stats
  const aliveCount = cars.filter(c => !c.damaged).length;
  aliveLabel.innerText = `${aliveCount} / ${N}`;
  genLabel.innerText = generation.toString();
  fitnessLabel.innerText = Math.abs(Math.round(bestCar.y - 100)).toString();

  // Network Visualizer
  networkCtx.lineDashOffset = -time / 50;
  if (visualBestCar.brain) {
    Visualizer.drawNetwork(networkCtx, visualBestCar.brain);
  }

  // Generation only ends when ALL cars have crashed
  if (aliveCount === 0) {
    nextGeneration();
  }

  requestAnimationFrame(animate);
}

function nextGeneration() {
  generation++;

  // Sort cars by distance traveled (best first)
  const sortedCars = [...cars].sort((a, b) => a.y - b.y);
  bestCar = sortedCars[0];

  const nextCars = generateCars(N);
  const mutationRate = parseFloat(mutationRateSlider.value);

  // Seed new cars with best car's brain
  for (let i = 0; i < nextCars.length; i++) {
    if (bestCar.brain) {
      nextCars[i].brain = JSON.parse(JSON.stringify(bestCar.brain));
      if (i != 0 && nextCars[i].brain) {
        // Variable mutation: some with small changes, some with big changes
        const variableMutation = i < N * 0.3 ? mutationRate * 0.5 : mutationRate * (1 + Math.random());
        Network.mutate(nextCars[i].brain!, variableMutation);
      }
    }
  }

  cars = nextCars;
  cameraY = 100; // Reset camera for new generation

  // Recreate traffic with fresh positions
  traffic = createTraffic();
}

animate();
